<?php
/**
 * This file include every customizer pannels code related.
 * Keep one file per pannel.
 */
include_once locate_template('/config/customizer/colors.php');

include_once locate_template('/config/customizer/custom_vars.php');

include_once locate_template('/config/customizer/homepage.php');

include_once locate_template('/config/customizer/social_networks.php');
