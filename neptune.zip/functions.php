<?php

include_once locate_template('/config/blog/index.php');

include_once locate_template('/config/clean/index.php');

include_once locate_template('/config/customizer/index.php');

include_once locate_template('/config/enqueue.php');

include_once locate_template('/config/editor/index.php');

include_once locate_template('/config/menus.php');

include_once locate_template('/config/theme_support.php');
