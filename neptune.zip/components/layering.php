<section class="layering">
    <div class="container">

        <h2>Theme based on Gutenberg editor</h2>

        <div class="cols">
            <div>
                <img src="http://localhost:8888/neptune/wp-content/uploads/2021/01/image.jpg" alt="Image.">
            </div>

            <div class="bloc">
                <h3>Use custom block</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque non sapien tincidunt, suscipit metus sed, hendrerit mi. Ut commodo tristique est, sed ornare sapien congue sed. </p>
                <p>Aliquam dui arcu, mollis sed ultricies vitae, dapibus a tortor. Aliquam pulvinar tempor enim, sit amet sodales nunc dictum quis.</p>
                <a class="btn btn-primary" href="#">Discover</a>
            </div>
        </div>

    </div>
</section>