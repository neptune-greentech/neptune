<section class="process bg">
    <div class="container">

        <div class="bloc">
            <h3>Our process</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque non sapien tincidunt, suscipit metus sed, hendrerit mi. Ut commodo tristique est, sed ornare sapien congue sed. </p>
            <p>Aliquam dui arcu, mollis sed ultricies vitae, dapibus a tortor. Aliquam pulvinar tempor enim, sit amet sodales nunc dictum quis.</p>
            <p>Etiam elit lectus, rutrum mattis porttitor eget, aliquam at nunc.</p>
        </div>

    </div>
</section>