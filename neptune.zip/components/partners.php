<section class="partners">
    <div class="container">

    <h2>Our partners</h2>

        <div class="partners_grid">
            <div>
                <img src="http://localhost:8888/neptune/wp-content/uploads/2021/01/logo-neptune.png" alt="Logo Neptune.">
            </div>
            <div>
                <img src="http://localhost:8888/neptune/wp-content/uploads/2021/01/logo-neptune.png" alt="Logo Neptune.">
            </div>
            <div>
                <img src="http://localhost:8888/neptune/wp-content/uploads/2021/01/logo-neptune.png" alt="Logo Neptune.">
            </div>
            <div>
                <img src="http://localhost:8888/neptune/wp-content/uploads/2021/01/logo-neptune.png" alt="Logo Neptune.">
            </div>
            <div>
                <img src="http://localhost:8888/neptune/wp-content/uploads/2021/01/logo-neptune.png" alt="Logo Neptune.">
            </div>
            <div>
                <img src="http://localhost:8888/neptune/wp-content/uploads/2021/01/logo-neptune.png" alt="Logo Neptune.">
            </div>
            <div>
                <img src="http://localhost:8888/neptune/wp-content/uploads/2021/01/logo-neptune.png" alt="Logo Neptune.">
            </div>
            <div>
                <img src="http://localhost:8888/neptune/wp-content/uploads/2021/01/logo-neptune.png" alt="Logo Neptune.">
            </div>
        </div>

    </div>
</section>