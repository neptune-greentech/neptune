<section>
    <div class="container">

        <h2>Our services</h2>

        <div class="col-3">
            <div class="col">
                <h3>Service 1</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque non sapien tincidunt, suscipit metus sed, hendrerit mi. Ut commodo tristique est, sed ornare sapien congue sed. </p>
            </div>

            <div class="col">
                <h3>Service 2</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque non sapien tincidunt, suscipit metus sed, hendrerit mi. Ut commodo tristique est, sed ornare sapien congue sed. </p>
            </div>

            <div class="col">
                <h3>Service 3</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque non sapien tincidunt, suscipit metus sed, hendrerit mi. Ut commodo tristique est, sed ornare sapien congue sed. </p>
            </div>
        </div>

    </div>
</section>