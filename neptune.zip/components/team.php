<section>
    <div class="container">

        <h2>The team</h2>

        <div class="col-3 team">
            <div class="col team_item">
                <img src="http://localhost:8888/neptune/wp-content/uploads/2021/01/image.jpg" alt="Image.">
                <div>
                    <p>Chief Information Officer</p>
                    <h3>Colleen Berube</h3>
                    <p>Lorem ipsum dolor sit amet consectetur adipiscing elit quisque non.</p>
                    <span></span>
                    <ul>
                        <li>
                            <img src="http://localhost:8888/neptune/wp-content/uploads/2021/01/icon-linkedin.png" alt="">
                            colleenberube
                        </li>
                        <li>
                            <img src="http://localhost:8888/neptune/wp-content/uploads/2021/01/icon-twitter.png" alt="">
                            colleenberube
                        </li>
                    </ul>
                </div>
            </div>

            <div class="col team_item">
                <img src="http://localhost:8888/neptune/wp-content/uploads/2021/01/image.jpg" alt="Image.">
                <div>
                    <p>Chief Creative Officer</p>
                    <h3>Take Nygaard Alserida</h3>
                    <p>Lorem ipsum dolor sit amet consectetur adipiscing elit quisque non.</p>
                    <span></span>
                    <ul>
                        <li>
                            <img src="http://localhost:8888/neptune/wp-content/uploads/2021/01/icon-linkedin.png" alt="">
                            takenygaard
                        </li>
                        <li>
                            <img src="http://localhost:8888/neptune/wp-content/uploads/2021/01/icon-twitter.png" alt="">
                            takenygaard
                        </li>
                    </ul>
                </div>
            </div>

            <div class="col team_item">
                <img src="http://localhost:8888/neptune/wp-content/uploads/2021/01/image.jpg" alt="Image.">
                <div>
                    <p>CEO Founder</p>
                    <h3>Mikkel Svane</h3>
                    <p>Lorem ipsum dolor sit amet consectetur adipiscing elit quisque non.</p>
                    <span></span>
                    <ul>
                        <li>
                            <img src="http://localhost:8888/neptune/wp-content/uploads/2021/01/icon-linkedin.png" alt="">
                            mikkelsvane
                        </li>
                        <li>
                            <img src="http://localhost:8888/neptune/wp-content/uploads/2021/01/icon-twitter.png" alt="">
                            mikkelsvane
                        </li>
                    </ul>
                </div>
            </div>
        </div>

    </div>
</section>