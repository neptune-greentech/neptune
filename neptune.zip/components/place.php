<section class="place">
    <div class="container">

        <div class="col-2 ">
            <div class="col">
                <h2>Bordeaux, France</h2>
                <p>88 rue judaïque, 33000</p>
                <p>06 49 29 18 64</p>
                <p>contact@neptune.fr</p>
            </div>
            <div class="col">
                <h2>Paris, France</h2>
                <p>88 rue judaïque, 33000</p>
                <p>06 49 29 18 64</p>
                <p>contact@neptune.fr</p>
            </div>
        </div>

        <span></span>

    </div>
</section>