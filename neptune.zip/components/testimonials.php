<section class="cols3-title">
    <div class="container">

        <h2>Our testimonials</h2>

        <div class="testimonials">
            <div class="prev">
                <img src="http://localhost:8888/neptune/wp-content/uploads/2021/01/icon-arrow-left.png" alt="Icon arrow left.">
            </div>

            <div class="next">
                <img src="http://localhost:8888/neptune/wp-content/uploads/2021/01/icon-arrow-right.png" alt="Icon arrow right.">
            </div>

            <div>
                <div class="bloc">

                    <div class="slider">
                        <div class="slider_inner">

                            <div class="slide">
                                <p>« Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque non sapien tincidunt, suscipit metus sed. »</p>
                                <p>John Doe</p>
                            </div>

                            <div class="slide">
                                <p>« Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque non sapien tincidunt, suscipit metus sed. »</p>
                                <p>Marie Doe</p>
                            </div>

                        </div>
                    </div>

                </div>

            </div>
        </div>
    </div>
</section>