<section class="contact">
    <div class="container">

        <form>
            <div class="col-2 ">
                <div class="col">
                    <label for="name">First and last name</label>
                    <input type="text" id="name" name="name" placeholder="Enter your first and last name">
                </div>
                <div class="col">
                    <label for="email">Email adress</label>
                    <input type="email" id="email" name="email" placeholder="Enter your email adress">
                </div>
            </div>

            <div class="col-1">
                <label for="message">Message</label>
                <textarea name="message" id="message" placeholder="Enter your message ..."></textarea>
            </div>

            <input type="submit" value="Send" class="btn btn-secondary">
        </form>

    </div>
</section>