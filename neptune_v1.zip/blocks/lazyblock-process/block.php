<section class="process bg" style="background-image:url('<?php echo $attributes['process_image']['url']; ?>')">
    <div class="container">

        <div class="bloc">
            <h3><?php echo $attributes['process_title']; ?></h3>
            <?php echo $attributes['process_text']; ?>
        </div>

    </div>
</section>
