<section class="gallery">
    <div class="container">

        <h2>View the gallery</h2>

        <div class="gallery_slider">
            <div class="gallery_slider_inner">
                <div class="gallery_slide"></div>
                <div class="gallery_slide"></div>
                <div class="gallery_slide"></div>
                <div class="gallery_slide"></div>
                <div class="gallery_slide"></div>
                <div class="gallery_slide"></div>
                <div class="gallery_slide"></div>
            </div>
        </div>

    </div>
</section>