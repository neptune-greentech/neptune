<section class="bg">
    <div class="container">

        <h2>Some numbers</h2>

        <div class="col-4 numbers">
            <div class="col">
                <div class="bloc">
                    <p>Performance</p>
                    <p>+ 40%</p>
                </div>
            </div>

            <div class="col">
                <div class="bloc">
                    <p>Carbon footprint</p>
                    <p>0.48 g of co2</p>
                </div>
            </div>

            <div class="col">
                <div class="bloc">
                    <p>Page size</p>
                    <p>0,245 mo</p>
                </div>
            </div>

            <div class="col">
                <div class="bloc">
                    <p>Users of this theme</p>
                    <p>236 persons</p>
                </div>
            </div>
        </div>

    </div>
</section>